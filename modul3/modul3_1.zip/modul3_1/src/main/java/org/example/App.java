package org.example;

public class App {
    public static void main(String[] args) {
        Tabung tabung = new Tabung("tabung");
        Kubus kubus = new Kubus("kubus");
        BangunRuang balok = new BangunRuang("balok");

        kubus.inputNilai();
        kubus.luasPermukaan();
        kubus.volume();

        tabung.inputNilai();
        tabung.luasPermukaan();
        tabung.volume();

        // Anggap saja Anda ingin menggunakan kelas BangunRuang di sini,
        // karena kelas Balok tidak didefinisikan dalam kode yang Anda berikan.
        balok.luasPermukaan();
        balok.volume();
    }
}
