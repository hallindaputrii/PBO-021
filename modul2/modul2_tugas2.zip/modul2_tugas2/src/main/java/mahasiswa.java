import java.util.Scanner;

class Mahasiswa {
        public String nama, jurusan, nim;
        public static String tampiluniversitas() {

            return "Universitas Muhammadiyah Malang\n";
        }

        public void inputdata(){
            Scanner input1 = new Scanner(System.in);
            System.out.print("Masukkan nama Mahasiswa: ");
            nama = input1.nextLine();

            System.out.print("Masukkan jurusan: ");
            jurusan = input1.nextLine();

            System.out.print("Masukkan NIM: ");
            nim = input1.nextLine();
            if (nim.length() < 15) {
                System.out.println("\nNIM harus 15 Digit!\n");

            } else if(nim.length() > 15){
                System.out.println("\nNIM harus 15 Digit!\n");
            }
            else {
                System.out.print("\nData berhasil ditambahkan\n");

            }

        }
        public String tampildatamahasiswa() {
            return "Nama: " + nama + "\nJurusan: " + jurusan + "\nNIM: " + nim ;
        }

}
